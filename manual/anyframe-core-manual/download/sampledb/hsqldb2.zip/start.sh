#!/bin/bash

java -cp ./hsqldb-2.0.0.jar org.hsqldb.server.Server --database.0 file:sampledb --dbname.0 sampledb
