#!/bin/bash
java -cp ./hsqldb-2.0.0.jar org.hsqldb.util.DatabaseManagerSwing --url jdbc:hsqldb:hsql://localhost/sampledb --user SA 